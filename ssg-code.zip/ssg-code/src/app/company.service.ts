import { Injectable } from '@angular/core';
import { Company } from './company.model';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class CompanyService {

  private companies: Company[] = [
    new Company(1,'Test A',['Salem'])
  ]

 companiesChanged = new Subject<Company[]>();

  constructor() { }

  getCompanies(){
    return this.companies.slice();
  }

  addCompany(companyname:string){
    const id = this.companies.length+1;
    const newcompany = new Company(id,companyname,[]);
    console.log(newcompany);
    this.companies.push(newcompany);
    this.companiesChanged.next(this.companies.slice());
  }

  deleteCompany(index){
    this.companies.splice(index,1);
    this.companiesChanged.next(this.companies.slice());
  }

  deleteBranch(row,col){
    this.companies[row].branches.splice(col,1);
    this.companiesChanged.next(this.companies.slice());
  }

  addBranch(companyid,branchname){
    
    const branched = this.companies.filter((item)=>{
      return (item.id === companyid);
    });

    //console.log('bran' + branched);

    this.companies[companyid-1].branches.push(branchname);
    console.log(this.companies);

    //this.companiesChanged.next(this.companies.slice());
  }
}
