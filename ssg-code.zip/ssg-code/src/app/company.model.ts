
export class Company{
    public id:number;
    public name: string;
    public branches: string[];

    constructor(id:number,name:string,branches:string[]){
        this.id=id;
        this.name=name;
        this.branches=branches;
    }
}