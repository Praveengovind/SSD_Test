import { AppComponent } from './app.component';
import { NgModule } from '@angular/core';
import { Router, Route, Routes, RouterModule } from '@angular/router';

const routes:Routes = [
    { path: '', redirectTo:'/companies', pathMatch:'full'},
    { path: 'companies', component: AppComponent}
];

@NgModule({
    imports: [
        RouterModule.forRoot(routes)
    ],
    exports:[ RouterModule  ]
})

export class AppRoutingModule{    
}


