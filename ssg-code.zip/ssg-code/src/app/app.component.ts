import { Company } from './company.model';
import { CompanyService } from './company.service';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  companies;
  isEdit = false;
  isBranchEdit = false;
  editIndex = null;
  editBranchIndex = null;

  @ViewChild('companyname') companyname: ElementRef;
  @ViewChild('branch') branch: ElementRef;
  @ViewChild('selectedCompany') selectedCompany: ElementRef;

  /**
   *
   */
  constructor(private service:CompanyService) {
    
  }

  ngOnInit(){
    this.companies = this.service.getCompanies();
    this.service.companiesChanged.subscribe((newlist:Company[])=>{
      this.companies = newlist;
    });
  }

  onCreateNew(companyname){
    console.log(companyname);
    this.service.addCompany(companyname);
  }

  onEdit(index){
    this.isEdit = true;
    this.editIndex = index;
    this.companyname.nativeElement.value=this.companies[index].name;
    console.log(this.isEdit);
  }

  onEditBranch(c_index,b_index){
    this.isBranchEdit = true;
    this.editIndex = c_index;
    this.editBranchIndex = b_index;
    console.log(c_index,b_index);
    const branch = this.companies[c_index].branches[b_index];
    this.branch.nativeElement.value=branch;
    this.selectedCompany.nativeElement.value=c_index+1;
    //console.log(branch);
  }

  onDelete(index){
    this.service.deleteCompany(index);
    //console.log(deleted);
  }

  onDeleteBranch(c_index,b_index){
    this.service.deleteBranch(c_index,b_index);
  }

  onUpdate(){    
    const updatedcompanies = this.companies.slice();
    updatedcompanies[this.editIndex].name = this.companyname.nativeElement.value;
    console.log(updatedcompanies);
    this.companyname.nativeElement.value = '';
    this.isEdit = false;
    this.editIndex = null;
  }

  onUpdateBranch(){  
    const updatedcompanies = this.companies.slice();
    console.log( updatedcompanies[this.editIndex]);
    updatedcompanies[this.editIndex].branches[this.editBranchIndex] = this.branch.nativeElement.value;
    this.selectedCompany.nativeElement.value=0;
    this.branch.nativeElement.value = '';
    this.editIndex = null;
    this.editBranchIndex = null;
  }

  onAddBranch(){
    //console.log(this.selectedCompany);
    //console.log(this.branch.nativeElement.value);
    const selectedCompany = this.selectedCompany.nativeElement.value;
    const newBranch = this.branch.nativeElement.value;
    this.service.addBranch(selectedCompany,newBranch);
    this.selectedCompany.nativeElement.value=0;
    this.branch.nativeElement.value = '';
  } 
}
